/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: raveriss <raveriss@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/04/15 18:38:25 by raveriss          #+#    #+#             */
/*   Updated: 2024/05/03 14:49:40 by raveriss         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Character.hpp"
#include "Ice.hpp"
#include "Cure.hpp"
#include "MateriaSource.hpp"

/* Inclusion bibliothèque I/O standard */
#include <iostream>

/**
 * @brief Fonction principale pour tester la gestion de matérias
 * @motclef simulation, utilisation de matérias, création personnages, interactions
 * @action crée source de matérias, apprend matérias, équipe personnages, utilise matérias,
 * nettoie mémoire
 */
int main()
{
    const int ICE_SLOT = 0;
    const int CURE_SLOT = 1;
    const int SECOND_ICE_SLOT = 2;
	
    IMateriaSource * src = new MateriaSource();
    if (!src)
		return -1;
    src->learnMateria(new Ice());
    src->learnMateria(new Cure());

    ICharacter * me = new Character("me");
    if (!me) {
        delete src;
		src = NULL;
        return -1;
    }

    AMateria * iceMateria = src->createMateria("ice");
    if (iceMateria)
		me->equip(iceMateria);

    AMateria * cureMateria = src->createMateria("cure");
    if (cureMateria)
		me->equip(cureMateria);

    AMateria * secondIceMateria = src->createMateria("ice");
    if (secondIceMateria)
		me->equip(secondIceMateria);
	
    ICharacter * bob = new Character("bob");
    if (!bob) {
        delete me;
		me = NULL;
        delete src;
		src = NULL;
        return -1;
    }

    me->unequip(CURE_SLOT);
    me->use(ICE_SLOT, * bob);
    me->use(CURE_SLOT, * bob);
    me->use(SECOND_ICE_SLOT, * bob);

    delete bob;
	bob = NULL;

    delete me;
	me = NULL;

    delete src;
	src = NULL;

	/*  Clean up if not equipped  */
    if (cureMateria) {
        delete cureMateria;
        cureMateria = NULL;
    }

    return 0;
}

/*  MAIN.CPP  */